
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Monster, Question } from '../types';
import { PLAYER_MAX_HP, PLAYER_DAMAGE, MONSTER_DAMAGE } from '../constants';
import { QUESTIONS } from '../data/questions';
import QuestionCard from './QuestionCard';
import HealthBar from './HealthBar';

interface BattleScreenProps {
  monster: Monster;
  onWin: () => void;
  onLoss: () => void;
}

const BattleScreen: React.FC<BattleScreenProps> = ({ monster, onWin, onLoss }) => {
  const [playerHP, setPlayerHP] = useState(PLAYER_MAX_HP);
  const [monsterHP, setMonsterHP] = useState(monster.hp);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [message, setMessage] = useState(`A wild ${monster.name} appears!`);
  const [playerTookDamage, setPlayerTookDamage] = useState(false);
  const [monsterTookDamage, setMonsterTookDamage] = useState(false);

  const relevantQuestions = useMemo(() => 
    QUESTIONS.filter(q => q.id.startsWith(monster.difficulty)), 
    [monster.difficulty]
  );

  const selectNewQuestion = useCallback(() => {
    const question = relevantQuestions[Math.floor(Math.random() * relevantQuestions.length)];
    setCurrentQuestion(question);
    setIsAnswered(false);
  }, [relevantQuestions]);

  useEffect(() => {
    selectNewQuestion();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (playerTookDamage || monsterTookDamage) {
      const timer = setTimeout(() => {
        setPlayerTookDamage(false);
        setMonsterTookDamage(false);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [playerTookDamage, monsterTookDamage]);
  

  const handleAnswer = (isCorrect: boolean) => {
    setIsAnswered(true);

    if (isCorrect) {
      const newMonsterHP = Math.max(0, monsterHP - PLAYER_DAMAGE);
      setMonsterHP(newMonsterHP);
      setMonsterTookDamage(true);
      setMessage(`Correct! You dealt ${PLAYER_DAMAGE} damage.`);

      if (newMonsterHP <= 0) {
        setTimeout(onWin, 2000);
      } else {
        setTimeout(selectNewQuestion, 2000);
      }
    } else {
      const newPlayerHP = Math.max(0, playerHP - MONSTER_DAMAGE);
      setPlayerHP(newPlayerHP);
      setPlayerTookDamage(true);
      setMessage(`Incorrect! The ${monster.name} strikes back for ${MONSTER_DAMAGE} damage.`);
      
      if (newPlayerHP <= 0) {
        setTimeout(onLoss, 2000);
      } else {
        setTimeout(selectNewQuestion, 2000);
      }
    }
  };

  return (
    <div className="w-full h-full flex flex-col p-4 md:p-8 bg-brand-surface rounded-xl shadow-2xl animate-fadeIn">
      {/* Top Section: Monster */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-8 mb-4">
        <div className="flex-1 text-center md:text-left">
          <h2 className="text-3xl font-bold text-brand-rose">{monster.name}</h2>
          <HealthBar currentHP={monsterHP} maxHP={monster.hp} color="bg-brand-rose" />
        </div>
        <div className={`flex items-center justify-center ${monsterTookDamage ? 'animate-flash' : ''}`}>
          {monster.image}
        </div>
      </div>

      {/* Message Log */}
      <div className="h-12 text-center my-4">
        <p className="text-lg italic text-brand-gold">{message}</p>
      </div>

      {/* Bottom Section: Player & Question */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-8 mt-4">
        <div className={`flex items-center justify-center ${playerTookDamage ? 'animate-shake' : ''}`}>
          <svg className="w-32 h-32 md:w-48 md:h-48 text-brand-info" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5">
            <path d="M12 21.4C16.9706 21.4 21 17.3706 21 12.4C21 7.42944 16.9706 3.4 12 3.4C7.02944 3.4 3 7.42944 3 12.4C3 14.3323 3.66696 16.1215 4.80757 17.5" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M10 17.4C10.6364 17.4 12.2727 17.4 13 16.4C14.4545 14.4 15.6364 11.4 15 10.4C14.3636 9.4 13.0909 9.9 12.5 10.4C11.9091 10.9 11.2727 12.4 12 12.9C12.7273 13.4 13.6364 13.4 14.5 12.9" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M7.5 12.4C7.5 12.4 8.5 11.4 10 11.4" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M16 14.4C15.8636 14.4 15.6364 14.4 15.5 14.9" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        <div className="flex-1 text-center md:text-right">
          <h2 className="text-3xl font-bold text-brand-info">You</h2>
          <HealthBar currentHP={playerHP} maxHP={PLAYER_MAX_HP} color="bg-brand-info" />
        </div>
      </div>
      
      {/* Question Card */}
      <div className="mt-8">
        {currentQuestion && (
          <QuestionCard
            question={currentQuestion}
            onAnswer={handleAnswer}
            isAnswered={isAnswered}
          />
        )}
      </div>
    </div>
  );
};

export default BattleScreen;
