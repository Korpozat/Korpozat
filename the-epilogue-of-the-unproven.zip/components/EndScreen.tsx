
import React from 'react';

interface EndScreenProps {
  won: boolean;
  onRestart: () => void;
}

const EndScreen: React.FC<EndScreenProps> = ({ won, onRestart }) => {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center p-8 bg-brand-surface rounded-xl shadow-2xl animate-fadeIn">
      {won ? (
        <>
          <h1 style={{fontFamily: "'Press Start 2P', cursive"}} className="text-3xl md:text-5xl font-bold text-brand-gold mb-4">
            Victory!
          </h1>
          <p className="text-lg text-brand-subtle max-w-2xl mb-8">
            Congratulations! You have vanquished all foes and proven your mastery of number theory. The realm is safe, thanks to your intellectual prowess.
          </p>
        </>
      ) : (
        <>
          <h1 style={{fontFamily: "'Press Start 2P', cursive"}} className="text-3xl md:text-5xl font-bold text-brand-danger mb-4">
            Defeated
          </h1>
          <p className="text-lg text-brand-subtle max-w-2xl mb-8">
            You fought bravely, but the monsters of ignorance were too strong this time. Review your proofs, sharpen your logic, and return to the quest!
          </p>
        </>
      )}
      <button
        onClick={onRestart}
        className="px-8 py-4 bg-brand-love text-brand-bg text-xl font-bold rounded-lg shadow-lg hover:bg-brand-iris transform hover:-translate-y-1 transition-all duration-300 ease-in-out"
        style={{fontFamily: "'Press Start 2P', cursive"}}
      >
        Play Again
      </button>
    </div>
  );
};

export default EndScreen;
