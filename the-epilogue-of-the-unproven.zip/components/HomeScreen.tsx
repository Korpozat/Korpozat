
import React from 'react';

interface HomeScreenProps {
  onStartGame: () => void;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ onStartGame }) => {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center p-8 bg-brand-surface rounded-xl shadow-2xl animate-fadeIn">
      <h1 style={{fontFamily: "'Press Start 2P', cursive"}} className="text-3xl md:text-5xl font-bold text-brand-gold mb-4 tracking-wider">
        The Epilogue of the Unproven
      </h1>
      <p className="text-lg text-brand-subtle max-w-2xl mb-8">
        Welcome, brave mathematician. Your journey through the perilous lands of Number Theory begins now. Defeat the monsters of misinformation by proving your knowledge. Your weapon is logic, your shield is reason.
      </p>
      <button
        onClick={onStartGame}
        className="px-8 py-4 bg-brand-love text-brand-bg text-xl font-bold rounded-lg shadow-lg hover:bg-brand-iris transform hover:-translate-y-1 transition-all duration-300 ease-in-out"
        style={{fontFamily: "'Press Start 2P', cursive"}}
      >
        Begin Quest
      </button>
    </div>
  );
};

export default HomeScreen;
