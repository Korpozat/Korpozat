
import React, { useState } from 'react';
import { Question } from '../types';
import { getExplanation } from '../services/geminiService';

interface QuestionCardProps {
  question: Question;
  onAnswer: (isCorrect: boolean) => void;
  isAnswered: boolean;
}

const optionLabels = ['A', 'B', 'C', 'D'];

const QuestionCard: React.FC<QuestionCardProps> = ({ question, onAnswer, isAnswered }) => {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [explanation, setExplanation] = useState<string>('');
  const [isExplaining, setIsExplaining] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);

  const handleOptionClick = (optionLabel: string) => {
    if (isAnswered) return;
    setSelectedOption(optionLabel);
    onAnswer(optionLabel === question.correct_label);
  };

  const handleExplainClick = async () => {
    if (explanation) {
      setShowExplanation(!showExplanation);
      return;
    }
    setIsExplaining(true);
    setShowExplanation(true);
    const result = await getExplanation(question);
    setExplanation(result);
    setIsExplaining(false);
  };

  const getButtonClass = (optionLabel: string) => {
    if (!isAnswered) {
      return 'bg-brand-overlay hover:bg-brand-muted';
    }
    if (optionLabel === question.correct_label) {
      return 'bg-brand-success text-brand-bg';
    }
    if (optionLabel === selectedOption && optionLabel !== question.correct_label) {
      return 'bg-brand-danger text-brand-bg';
    }
    return 'bg-brand-overlay opacity-50';
  };

  return (
    <div className="bg-brand-overlay p-6 rounded-lg shadow-inner">
      <p className="text-sm text-brand-subtle mb-1">Topic: {question.topic}</p>
      <h3 className="text-xl font-semibold text-brand-text mb-4">{question.question}</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {question.options.map((option, index) => {
          const label = optionLabels[index];
          return (
            <button
              key={label}
              onClick={() => handleOptionClick(label)}
              disabled={isAnswered}
              className={`p-3 text-left rounded-md transition-all duration-300 ${getButtonClass(label)} disabled:cursor-not-allowed`}
            >
              <span className="font-bold mr-2">{label}.</span>
              {option}
            </button>
          );
        })}
      </div>
      {isAnswered && (
        <div className="mt-4 text-center">
            <button 
              onClick={handleExplainClick}
              className="px-4 py-2 bg-brand-pine text-brand-text rounded-md hover:bg-brand-foam hover:text-brand-bg transition-colors"
            >
              {isExplaining ? 'Thinking...' : (showExplanation ? 'Hide Explanation' : 'Explain Concept')}
            </button>
            {showExplanation && (
              <div className="mt-4 p-4 bg-brand-bg rounded-md text-left text-brand-subtle animate-fadeIn">
                {isExplaining ? <p>Generating explanation...</p> : 
                  <div className="prose prose-invert prose-p:text-brand-subtle prose-strong:text-brand-text" dangerouslySetInnerHTML={{ __html: explanation.replace(/\n/g, '<br />') }}/>
                }
              </div>
            )}
        </div>
      )}
    </div>
  );
};

export default QuestionCard;
