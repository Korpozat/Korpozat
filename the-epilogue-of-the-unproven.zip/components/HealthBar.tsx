
import React from 'react';

interface HealthBarProps {
  currentHP: number;
  maxHP: number;
  color: string;
}

const HealthBar: React.FC<HealthBarProps> = ({ currentHP, maxHP, color }) => {
  const percentage = maxHP > 0 ? (currentHP / maxHP) * 100 : 0;

  return (
    <div className="w-full bg-brand-muted rounded-full h-6 my-2 border-2 border-brand-overlay overflow-hidden">
      <div
        className={`${color} h-full rounded-full transition-all duration-500 ease-out flex items-center justify-center`}
        style={{ width: `${percentage}%` }}
      >
        <span className="text-sm font-bold text-brand-bg mix-blend-screen">
          {currentHP} / {maxHP}
        </span>
      </div>
    </div>
  );
};

export default HealthBar;
