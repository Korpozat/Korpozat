
export const PLAYER_MAX_HP = 200;
export const PLAYER_DAMAGE = 50;
export const MONSTER_DAMAGE = 30;
