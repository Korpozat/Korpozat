
import React from 'react';
import type { Monster } from '../types';

const LemmaMonsterIcon: React.FC<{className?: string}> = ({className}) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5">
    <path d="M4 21.4V2.6C4 2.26863 4.26863 2 4.6 2H16.4558C16.5992 2 16.7362 2.05655 16.8435 2.15645L20.8435 5.65645C20.9434 5.76384 21 5.90076 21 6.04424V21.4C21 21.7314 20.7314 22 20.4 22H4.6C4.26863 22 4 21.7314 4 21.4Z" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M16 2V6H21" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M7 12H17" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M7 16H13" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const ContradictionDragonIcon: React.FC<{className?: string}> = ({className}) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5">
    <path d="M9.25 18.9632C4.25 17.2632 4.02 11.2332 6.5 7.93325C7.22727 6.99426 8.16364 6.22759 9.25 5.67325C13.25 3.55325 17.5 7.48325 17.5 7.48325C17.5 7.48325 22 6.48325 22 10.4832C22 14.4832 17.5 13.4832 17.5 13.4832C17.5 13.4832 17.5 18.4832 14 20.4832C13.5912 20.6976 13.151 20.8524 12.693 20.9432C11.5 21.1932 9.25 20.9632 9.25 18.9632Z" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M2 13.9772C2.86364 12.3105 4.13636 11.0378 5.68182 10.2772L9.25 18.9659C9.25 20.9659 11.5 21.1959 12.693 20.9459C13.151 20.8553 13.5912 20.6991 14 20.4859" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M15.5 11C15.5 11.2761 15.2761 11.5 15 11.5C14.7239 11.5 14.5 11.2761 14.5 11C14.5 10.7239 14.7239 10.5 15 10.5C15.2761 10.5 15.5 10.7239 15.5 11Z" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

const TheoremTitanIcon: React.FC<{className?: string}> = ({className}) => (
 <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5">
    <path d="M4 12.9L7.75 18L10.375 14.5M4 12.9L12 3L20 12.9M4 12.9H20M20 12.9L13.625 14.5L16.25 18L20 12.9Z" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M8.5 21H15.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);


export const MONSTERS: Monster[] = [
  {
    name: "Lemma Monster",
    hp: 200,
    difficulty: "LEMMA",
    image: <LemmaMonsterIcon className="w-32 h-32 md:w-48 md:h-48 text-brand-foam" />,
  },
  {
    name: "Contradiction Dragon",
    hp: 300,
    difficulty: "CONTRA",
    image: <ContradictionDragonIcon className="w-32 h-32 md:w-48 md:h-48 text-brand-rose" />,
  },
  {
    name: "Theorem Titan",
    hp: 500,
    difficulty: "THM",
    image: <TheoremTitanIcon className="w-32 h-32 md:w-48 md:h-48 text-brand-gold" />,
  },
];
