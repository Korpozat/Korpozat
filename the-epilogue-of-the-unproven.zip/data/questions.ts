
import type { Question } from '../types';

export const QUESTIONS: Question[] = [
    {
        "id": "LEMMA_1",
        "topic": "Number Theory",
        "question": "Which statement defines divisibility between two integers a and b?",
        "options": [
            "a divides b if there exists an integer k such that b = ak",
            "b divides a if there exists an integer k such that a = bk",
            "a divides b if a = b + k",
            "b divides a if b = a + k"
        ],
        "correct_label": "B",
        "key_phrases": [
            "a = bk",
            "b divides a",
            "k ∈ Z"
        ]
    },
    {
        "id": "LEMMA_2",
        "topic": "Number Theory",
        "question": "If a | b and b | c, what can we conclude about a and c?",
        "options": [
            "a divides c",
            "c divides a",
            "a + b divides c",
            "a divides b but not c"
        ],
        "correct_label": "A",
        "key_phrases": [
            "transitivity of divisibility",
            "a | c"
        ]
    },
    {
        "id": "LEMMA_3",
        "topic": "Number Theory",
        "question": "If a | b and a | c, then for any integers m and n, which of the following is true?",
        "options": [
            "a divides mb + nc",
            "a divides b + c only",
            "a divides m + n",
            "a divides b but not nc"
        ],
        "correct_label": "A",
        "key_phrases": [
            "a | (mb + nc)",
            "linear combinations"
        ]
    },
    {
        "id": "LEMMA_4",
        "topic": "Number Theory",
        "question": "According to the Well-Ordering Principle, every non-empty subset of the positive integers has:",
        "options": [
            "a greatest element",
            "a least element",
            "no bounds",
            "exactly one element"
        ],
        "correct_label": "B",
        "key_phrases": [
            "least element",
            "Z+"
        ]
    },
    {
        "id": "LEMMA_5",
        "topic": "Number Theory",
        "question": "What does gcd(a, b) = 1 imply about integers a and b?",
        "options": [
            "They are both prime",
            "They are coprime",
            "They are equal",
            "They are multiples of each other"
        ],
        "correct_label": "B",
        "key_phrases": [
            "coprime",
            "relatively prime"
        ]
    },
    {
        "id": "LEMMA_6",
        "topic": "Number Theory",
        "question": "Which proposition allows us to reduce gcd(a, b) to gcd(b, r)?",
        "options": [
            "Division Algorithm",
            "Cancellation Lemma",
            "Euclidean Algorithm",
            "Proposition 10"
        ],
        "correct_label": "D",
        "key_phrases": [
            "a = bq + r",
            "gcd(a, b) = gcd(b, r)"
        ]
    },
    {
        "id": "LEMMA_7",
        "topic": "Number Theory",
        "question": "According to Bézout’s Identity, if d = gcd(a, b), then:",
        "options": [
            "a divides b and b divides a",
            "d = am + bn for some integers m, n",
            "a + b = d",
            "a and b are coprime"
        ],
        "correct_label": "B",
        "key_phrases": [
            "am + bn = d",
            "gcd",
            "linear combination"
        ]
    },
    {
        "id": "CONTRA_1",
        "topic": "Number Theory",
        "question": "What is the key idea behind proofs by contradiction?",
        "options": [
            "Assume the conclusion is true and prove the hypothesis",
            "Assume the negation of the statement and reach an impossibility",
            "Use induction on the negated hypothesis",
            "List all counterexamples and eliminate them"
        ],
        "correct_label": "B",
        "key_phrases": [
            "assume the opposite",
            "contradiction"
        ]
    },
    {
        "id": "CONTRA_2",
        "topic": "Number Theory",
        "question": "Which theorem uses the Well-Ordering Principle in its proof of the Division Algorithm?",
        "options": [
            "Euclid’s Lemma",
            "Bézout’s Identity",
            "The Division Algorithm",
            "Fermat’s Little Theorem"
        ],
        "correct_label": "C",
        "key_phrases": [
            "a = bq + r",
            "0 ≤ r < b",
            "unique q and r"
        ]
    },
    {
        "id": "CONTRA_3",
        "topic": "Number Theory",
        "question": "In the proof of the Fundamental Theorem of Arithmetic, what is the contradiction reached if a counterexample exists?",
        "options": [
            "There exists an infinite number of primes",
            "The smallest number without prime factorization can be written as one",
            "A number has no factors",
            "Prime factorization is non-unique"
        ],
        "correct_label": "B",
        "key_phrases": [
            "Well-Ordering Principle",
            "minimal element",
            "contradiction"
        ]
    },
    {
        "id": "CONTRA_4",
        "topic": "Number Theory",
        "question": "In Euclid’s proof of the infinitude of primes, what is the constructed number?",
        "options": [
            "The product of all primes",
            "The sum of all primes",
            "The product of all primes plus one",
            "A random prime not in the list"
        ],
        "correct_label": "C",
        "key_phrases": [
            "p1p2...pn + 1",
            "infinitely many primes"
        ]
    },
    {
        "id": "CONTRA_5",
        "topic": "Number Theory",
        "question": "Which statement about √p is proven using contradiction for prime p?",
        "options": [
            "It is rational",
            "It is irrational",
            "It equals an integer",
            "It is undefined"
        ],
        "correct_label": "B",
        "key_phrases": [
            "√p is irrational",
            "contradiction"
        ]
    },
    {
        "id": "CONTRA_6",
        "topic": "Number Theory",
        "question": "In the Fundamental Theorem of Arithmetic, what assumption leads to contradiction in uniqueness?",
        "options": [
            "Two equal prime factorizations exist",
            "Two different prime factorizations exist",
            "The number is prime",
            "The primes are composite"
        ],
        "correct_label": "B",
        "key_phrases": [
            "unique prime factorization",
            "contradiction"
        ]
    },
    {
        "id": "CONTRA_7",
        "topic": "Number Theory",
        "question": "In Fermat’s Little Theorem, what is assumed false in a contradiction-based proof?",
        "options": [
            "p divides a",
            "p is prime",
            "a^(p-1) ≡ 1 (mod p)",
            "a and p are coprime"
        ],
        "correct_label": "C",
        "key_phrases": [
            "a^(p-1) ≡ 1 mod p"
        ]
    },
    {
        "id": "THM_1",
        "topic": "Number Theory",
        "question": "The Division Algorithm guarantees that for integers a and b > 0, there exist unique integers q and r such that:",
        "options": [
            "a = bq + r, where 0 ≤ r < b",
            "a = qb + r, where 0 ≤ q < b",
            "b = aq + r, where 0 ≤ r < a",
            "r = aq + b, where 0 ≤ q < a"
        ],
        "correct_label": "A",
        "key_phrases": [
            "a = bq + r",
            "0 ≤ r < b",
            "unique"
        ]
    },
    {
        "id": "THM_2",
        "topic": "Number Theory",
        "question": "Bézout’s Identity states that for integers a and b, gcd(a, b) can be expressed as:",
        "options": [
            "a/b",
            "a + b",
            "am + bn",
            "a × b"
        ],
        "correct_label": "C",
        "key_phrases": [
            "am + bn = gcd(a, b)"
        ]
    },
    {
        "id": "THM_3",
        "topic": "Number Theory",
        "question": "Which theorem asserts that if p is prime and p divides ab, then p divides a or b?",
        "options": [
            "Fermat’s Little Theorem",
            "Euclid’s Lemma",
            "Division Algorithm",
            "Fundamental Theorem of Arithmetic"
        ],
        "correct_label": "B",
        "key_phrases": [
            "p | ab → p | a or p | b"
        ]
    },
    {
        "id": "THM_4",
        "topic": "Number Theory",
        "question": "Fermat’s Little Theorem states that if p is prime and p does not divide a, then:",
        "options": [
            "a^p ≡ 1 (mod p)",
            "a^(p-1) ≡ 1 (mod p)",
            "p^a ≡ 1 (mod a)",
            "a^p ≡ p (mod a)"
        ],
        "correct_label": "B",
        "key_phrases": [
            "a^(p-1) ≡ 1 mod p"
        ]
    },
    {
        "id": "THM_5",
        "topic": "Number Theory",
        "question": "The Fundamental Theorem of Arithmetic states that every integer greater than 1 can be:",
        "options": [
            "written as a product of primes, uniquely up to order",
            "expressed as a power of two",
            "divided evenly by all primes",
            "written as the sum of primes"
        ],
        "correct_label": "A",
        "key_phrases": [
            "unique prime factorization"
        ]
    },
    {
        "id": "THM_6",
        "topic": "Number Theory",
        "question": "Euclid’s Proof of the Infinitude of Primes shows that:",
        "options": [
            "There are finitely many primes",
            "Every number is prime",
            "There are infinitely many primes",
            "Primes repeat every 10 numbers"
        ],
        "correct_label": "C",
        "key_phrases": [
            "infinitely many primes",
            "p1p2...pn + 1"
        ]
    }
];
