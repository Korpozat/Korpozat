
import React, { useState, useCallback } from 'react';
import { MONSTERS } from './data/monsters';
import HomeScreen from './components/HomeScreen';
import BattleScreen from './components/BattleScreen';
import EndScreen from './components/EndScreen';
import { GameState } from './types';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.Home);
  const [currentMonsterIndex, setCurrentMonsterIndex] = useState(0);

  const startGame = useCallback(() => {
    setCurrentMonsterIndex(0);
    setGameState(GameState.Battle);
  }, []);

  const handleBattleWin = useCallback(() => {
    if (currentMonsterIndex < MONSTERS.length - 1) {
      setCurrentMonsterIndex(prevIndex => prevIndex + 1);
    } else {
      setGameState(GameState.GameWon);
    }
  }, [currentMonsterIndex]);

  const handleBattleLoss = useCallback(() => {
    setGameState(GameState.GameLost);
  }, []);

  const renderContent = () => {
    switch (gameState) {
      case GameState.Home:
        return <HomeScreen onStartGame={startGame} />;
      case GameState.Battle:
        return (
          <BattleScreen
            monster={MONSTERS[currentMonsterIndex]}
            onWin={handleBattleWin}
            onLoss={handleBattleLoss}
            key={currentMonsterIndex} // Re-mount component for each new monster
          />
        );
      case GameState.GameWon:
        return <EndScreen won={true} onRestart={startGame} />;
      case GameState.GameLost:
        return <EndScreen won={false} onRestart={startGame} />;
      default:
        return <HomeScreen onStartGame={startGame} />;
    }
  };

  return (
    <div className="bg-brand-bg text-brand-text min-h-screen w-full flex items-center justify-center font-sans p-4">
      <div className="w-full max-w-5xl mx-auto">
        {renderContent()}
      </div>
    </div>
  );
};

export default App;
