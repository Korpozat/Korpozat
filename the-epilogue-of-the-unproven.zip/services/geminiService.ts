
import { GoogleGenAI } from "@google/genai";
import type { Question } from '../types';

// IMPORTANT: This relies on the API key being available in the environment.
// Do not hardcode the API key here.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getExplanation = async (question: Question): Promise<string> => {
  const { question: qText, options, correct_label, key_phrases } = question;
  const correctOptionIndex = correct_label.charCodeAt(0) - 'A'.charCodeAt(0);
  const correctOptionText = options[correctOptionIndex];

  const prompt = `
    You are an expert math professor specializing in Number Theory. 
    A student is playing an educational game and needs a clear, concise explanation for a multiple-choice question they just answered.
    Explain the core mathematical concept behind this question in a way that is easy to understand for a first-year university student who might be struggling.
    - Start by explaining the main theorem or definition.
    - Clarify why the correct answer is right based on this concept.
    - Briefly mention why the other options are incorrect.
    - Use Markdown for formatting (bold for key terms, lists if helpful).

    Question: "${qText}"
    Options:
    A: ${options[0]}
    B: ${options[1]}
    C: ${options[2]}
    D: ${options[3]}

    Correct Answer: (${correct_label}) ${correctOptionText}
    Key Concepts: ${key_phrases.join(', ')}

    Provide your explanation below.
  `;

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error generating explanation:", error);
    return "Sorry, an error occurred while generating an explanation. Please ensure your API key is configured correctly and check the console for details.";
  }
};
