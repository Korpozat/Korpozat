
import type React from 'react';

export interface Question {
  id: string;
  topic: string;
  question: string;
  options: string[];
  correct_label: 'A' | 'B' | 'C' | 'D';
  key_phrases: string[];
}

export interface Monster {
  name: string;
  hp: number;
  difficulty: 'LEMMA' | 'CONTRA' | 'THM';
  image: React.ReactNode;
}

export enum GameState {
  Home = 'HOME',
  Battle = 'BATTLE',
  GameWon = 'GAME_WON',
  GameLost = 'GAME_LOST'
}
